# Atividade - Árvore Binária de Busca

Atividade da disciplina de Estrutura de Dados II sobre árvores simples e busca em Árvore Binária de Busca (ABB).

## Objetivo

O objetivo da atividade é representar uma ABB e mostrar como funciona a busca de um valor usando comparações.

Na ABB:
- valores menores ficam à esquerda;
- valores maiores ficam à direita;
- não foram usados valores duplicados.

## Árvore usada

Os valores usados foram:

`50, 30, 70, 20, 40, 60, 80`

A árvore fica assim:

```text
        50
       /  \
     30    70
    / \    / \
   20 40  60 80
```

## Busca pelo valor 60

A busca acontece da seguinte forma:

1. Começa no valor 50.
2. Como 60 é maior que 50, vai para a direita.
3. Chega no valor 70.
4. Como 60 é menor que 70, vai para a esquerda.
5. Chega no valor 60.
6. O valor é encontrado.

Caminho percorrido:

`50 -> 70 -> 60`

## Arquivo Python

O arquivo `arvore_abb.py` possui a classe `No`, a função de inserção, a função de busca, a criação da árvore e um teste procurando o valor 60.

Ao executar, o resultado esperado é:

```text
Valor procurado: 60
Caminho percorrido: [50, 70, 60]
Resultado: valor encontrado!
```

## Mini GDD

Também foi feito um Mini GDD com uma proposta simples de busca em um catálogo usando a lógica da ABB.
